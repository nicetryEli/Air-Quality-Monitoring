package com.aqi.warning.controller;

import com.aqi.warning.dto.ForecastIngestRequest;
import com.aqi.warning.dto.ForecastIngestResponse;
import com.aqi.warning.service.ForecastService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v2/internal/forecasts")
@RequiredArgsConstructor
public class MlForecastIngestController {

    private final ForecastService forecastService;

    /**
     * API Nhận dữ liệu dự báo từ Python ML Model Pipeline (US08, US09)
     * POST /api/v2/internal/forecasts/ingest
     * Mô hình đẩy dữ liệu 24-48 giờ tới, backend lưu DB & tự động quét sinh AlertEvent nếu AQI > 100/150
     */
    @PostMapping("/ingest")
    public ResponseEntity<ForecastIngestResponse> ingestForecastData(
            @RequestHeader(value = "X-ML-API-KEY", required = false) String apiKey, // Bảo mật giữa ML service & Backend
            @Valid @RequestBody ForecastIngestRequest request) {

        ForecastIngestResponse response = forecastService.processAndSaveForecasts(request);
        return ResponseEntity.ok(response);
    }
}