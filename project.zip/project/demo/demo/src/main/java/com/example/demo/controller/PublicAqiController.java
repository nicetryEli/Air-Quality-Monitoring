package com.aqi.warning.controller;

import com.aqi.warning.dto.AqiHistoryResponse;
import com.aqi.warning.service.AqiService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/v2/public/aqi")
@RequiredArgsConstructor
@CrossOrigin(origins = "*") // Công khai cho mọi người dân truy cập không cần token
public class PublicAqiController {

    private final AqiService aqiService;

    /**
     * API 10: Xem lịch sử AQI theo trạm và khoảng thời gian (US10)
     * GET /api/v2/public/aqi/history?stationId=1&fromDate=2026-09-01T00:00:00&toDate=2026-09-10T23:59:59
     */
    @GetMapping("/history")
    public ResponseEntity<List<AqiHistoryResponse>> getAqiHistory(
            @RequestParam Long stationId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fromDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime toDate) {

        List<AqiHistoryResponse> history = aqiService.getAqiHistory(stationId, fromDate, toDate);
        return ResponseEntity.ok(history);
    }
}