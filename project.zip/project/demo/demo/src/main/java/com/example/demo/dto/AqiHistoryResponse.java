package com.aqi.warning.dto;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Builder
public class AqiHistoryResponse {
    private Long stationId;
    private String stationName;
    private LocalDateTime timestamp;
    private Float aqi;
    private String category; // Tốt, Trung bình, Kém, Xấu, Nguy hại
    private Float pm25;
    private Float pm10;
}