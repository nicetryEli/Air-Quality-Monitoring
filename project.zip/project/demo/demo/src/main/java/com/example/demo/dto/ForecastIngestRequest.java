package com.aqi.warning.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ForecastIngestRequest {
    private Long stationId;
    private String modelVersion; // VD: "v2.1"
    private List<ForecastDetail> forecasts;

    @Data
    public static class ForecastDetail {
        private LocalDateTime forecastTime; // Thời điểm dự báo (24h - 48h tới)
        private Float predictedAqi;
        private Float confidenceLower;     // Khoảng tin cậy dưới
        private Float confidenceUpper;     // Khoảng tin cậy trên
    }
}