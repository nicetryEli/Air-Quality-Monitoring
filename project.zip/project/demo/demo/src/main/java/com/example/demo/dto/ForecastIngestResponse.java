package com.aqi.warning.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ForecastIngestResponse {
    private boolean success;
    private String message;
    private int recordsIngested;
    private int alertsTriggered; // Số lượng cảnh báo tự động tạo ra (nếu AQI > 100/150)
}