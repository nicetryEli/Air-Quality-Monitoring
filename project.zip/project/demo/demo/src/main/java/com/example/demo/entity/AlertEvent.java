package com.aqi.warning.entity;

import lombok.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "alert_events")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AlertEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "alert_id")
    private Long alertId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "station_id", nullable = false)
    private Station station;

    @Column(name = "forecast_id")
    private Long forecastId; // Nullable, tham chiếu đến AQI_FORECASTS

    @Column(name = "aqi_value", nullable = false)
    private Float aqiValue;

    @Column(name = "alert_level", nullable = false, length = 50)
    private String alertLevel; // "SensitiveGroup", "Hazard"

    @Column(name = "banner_message", nullable = false)
    private String bannerMessage;

    @Column(name = "triggered_at", nullable = false)
    private LocalDateTime triggeredAt;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt; // Null nếu banner đang active, có giá trị khi AQI giảm dưới ngưỡng
}