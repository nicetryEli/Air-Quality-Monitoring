package com.aqi.warning.entity;

import lombok.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ml_models")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MlModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "model_id")
    private Long modelId;

    @Column(nullable = false, length = 50)
    private String version;

    @Column(name = "trained_at")
    private LocalDateTime trainedAt;

    private Double accuracy;
    private Double mae;
    private Double rmse;

    @Column(length = 20)
    private String status; // "Ready", "Archived"
}