package com.aqi.warning.entity;

import lombok.*;
import jakarta.persistence.*;

@Entity
@Table(name = "stations")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Station {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "station_id")
    private Long stationId;

    @Column(nullable = false, unique = true, length = 100)
    private String name; // Tên trạm (VD: Guanyuan, Dongsi)

    @Column(length = 100)
    private String district; // Quận/Huyện

    private Double latitude;

    private Double longitude;

    @Column(length = 20)
    private String status; // "ACTIVE", "INACTIVE"
}