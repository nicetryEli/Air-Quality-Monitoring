package com.aqi.warning.service;

import com.aqi.warning.dto.AqiHistoryResponse;
import java.time.LocalDateTime;
import java.util.List;

public interface AqiService {
    
    /**
     * Lấy danh sách lịch sử AQI của một trạm trong khoảng thời gian quy định (US10)
     */
    List<AqiHistoryResponse> getAqiHistory(Long stationId, LocalDateTime fromDate, LocalDateTime toDate);
}