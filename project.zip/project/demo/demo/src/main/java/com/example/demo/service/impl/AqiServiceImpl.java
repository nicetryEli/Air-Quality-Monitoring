package com.aqi.warning.service.impl;

import com.aqi.warning.dto.AqiHistoryResponse;
import com.aqi.warning.entity.Station;
import com.aqi.warning.repository.StationRepository;
import com.aqi.warning.service.AqiService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AqiServiceImpl implements AqiService {

    private final StationRepository stationRepository;

    @Override
    @Transactional(readOnly = true)
    public List<AqiHistoryResponse> getAqiHistory(Long stationId, LocalDateTime fromDate, LocalDateTime toDate) {
        Station station = stationRepository.findById(stationId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy trạm quan trắc với ID: " + stationId));

        // Logic truy vấn lịch sử dữ liệu AQI (Có thể truy vấn từ Repository của dữ liệu quan trắc)
        List<AqiHistoryResponse> historyList = new ArrayList<>();

        // Giả lập/Map dữ liệu lịch sử phục vụ API 10 (US10)
        // Trong triển khai thực tế: Gọi Repo lấy dữ liệu theo stationId và khoảng thời gian (fromDate -> toDate)
        
        return historyList;
    }

    /**
     * Hàm phụ trợ phân loại mức độ AQI theo chuẩn công khai v2.0
     */
    private String determineCategory(Float aqi) {
        if (aqi == null) return "Chưa có dữ liệu";
        if (aqi <= 50) return "Tốt";
        if (aqi <= 100) return "Trung bình";
        if (aqi <= 150) return "Kém";
        if (aqi <= 200) return "Xấu";
        return "Nguy hại";
    }
}